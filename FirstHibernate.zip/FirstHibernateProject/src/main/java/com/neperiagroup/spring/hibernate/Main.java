package com.neperiagroup.spring.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		
		User user = new User();
		user.setName("Michele");
		user.setSurname("Zama");
		user.setEmail("michelezama@gmail.com");
		user.setPassword("123");
		
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		System.out.println("user: "+user);
		
		session.save(user);
		
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
	}
}